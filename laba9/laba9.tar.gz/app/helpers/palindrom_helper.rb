module PalindromHelper
end
